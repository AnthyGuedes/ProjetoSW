/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import beans.Comanda;
import Restaurante.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ComandaDAO {
    public void inserir(Comanda comanda) {
        // Implementação de inserção no banco
    }
    
    public List<Comanda> listar() {
        // Implementação para listar comandas
        return new ArrayList<>();
    }
}